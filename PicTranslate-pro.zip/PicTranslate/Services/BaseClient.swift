//
//  BaseClient.swift
//  BitEclipse
//
//  Created by Nhuom Tang on 24/4/19.
//  Copyright © 2019 Nhuom Tang. All rights reserved.
//

import UIKit
import Alamofire
import ObjectMapper
import PromiseKit

class BaseClient {
    
    static let shared = BaseClient(baseURLString: "https://translate.yandex.net/api/v1.5/tr.json/")
    
    fileprivate (set) var baseURLString: String
    
    var accessToken: String?//Set this value for api client sending request after user logged in
    
    var defaultHeaders: Dictionary<String, String> {
        return [:]
    }
    
    var authenticator: (( _ header: inout HTTPHeaders, _ parameters: inout Parameters) -> Void)?
    
    lazy var sessionManager: SessionManager = {
        let configuration = URLSessionConfiguration.default
        var headers = SessionManager.defaultHTTPHeaders
        configuration.httpAdditionalHeaders = headers
        return SessionManager(configuration: configuration)
    }()
    
    init(baseURLString: String) {
        self.baseURLString = baseURLString
    }
    
    // MARK: -- Private Methods
    
    fileprivate func resolvePath(_ path: String) -> String {
        return baseURLString + path;
    }
    
    func request(
        _ method: HTTPMethod,
        _ path: String,
        parameters: Parameters? = nil,
        encoding: ParameterEncoding = JSONEncoding.default,
        headers: HTTPHeaders? = nil)
        -> DataRequest
    {
        let requestURL = URL(string: resolvePath(path))
        var requestHeaders = HTTPHeaders()
        var requestParams = Parameters()
        
        for (key, value) in defaultHeaders {
            requestHeaders[key] = value
        }
        
        if let parameters = parameters {
            for (key, value) in parameters {
                requestParams[key] = value
            }
        }
        
        if let headers = headers {
            for (key, value) in headers {
                requestHeaders[key] = value
            }
        }
        
        if let authenticator = authenticator {
            authenticator(&requestHeaders, &requestParams)
        }
                
        let request = sessionManager.request(requestURL!, method: method, parameters: requestParams, encoding: encoding, headers: requestHeaders)
        
        #if DEBUG
        request.responseString { [weak request](response: DataResponse<String>) in
            switch response.result {
            case .success(let value):
                if let data = value.data(using: .utf8) {
                    do {
                        let json = try JSONSerialization.jsonObject(with: data, options: [])
                        let jsonData = try JSONSerialization.data(withJSONObject: json, options: [JSONSerialization.WritingOptions.prettyPrinted])
                        _ = String(data: jsonData, encoding: .utf8) ?? ""
                        //debugPrint("Response:\n===============\n\(jsonString)\n===============")
                    } catch {
                        //debugPrint("Response:\n===============\n\(value)\n===============")
                    }
                } else {
                    //debugPrint("Response:\n===============\n\(value)\n===============")
                }
            case .failure(let error):
                debugPrint("Response:\n===============\n\(error)\n===============")
                break
            }
        }
        #endif
        return request.validate(statusCode: 0..<1000)
    }
    
    /**
     This is depend on json response.
     All response must contains "data" key.
     */
    static func processResponse(request:URLRequest?,
                                response: HTTPURLResponse?,
                                data: Data?,
                                error: Error?) -> AppResult<Any> {
        guard error == nil else {
            if let error = error as? AFError{
                if error._code == NSURLErrorTimedOut {
                    return .failure(ServiceError.timeout)
                }
            }
            return .failure(error!)
        }
        
        guard let _ = data else {//Empty data response
            if let error = error as? AFError{
                if error._code == NSURLErrorTimedOut {
                    return .failure(ServiceError.timeout)
                }
            }
            return .failure(ServiceError.emptyResponse)
        }
        
        let jsonResponseSerializer = DataRequest.jsonResponseSerializer(options: .allowFragments)
        let result = jsonResponseSerializer.serializeResponse(request, response, data, error)
        
        if result.isFailure {
            if let error = error as? AFError{
                if error._code == NSURLErrorTimedOut {
                    return .failure(ServiceError.timeout)
                }
            }
            return .failure(ServiceError.invalidDataFormat)
        }
        
        if let json = result.value as? [String: Any] {
            return .success(json)
        }
        
        if let json = result.value as? [[String: Any]] {
            return .success(json)
        }
        
        return .failure(ServiceError.undefined)
    }
    
    static func responseObjectSerializer(subKey: String? = nil) -> DataResponseSerializer<Any> {
        return DataResponseSerializer(serializeResponse: { (request, response, data, error) -> AppResult<Any> in
            let result = processResponse(request: request, response: response, data: data, error: error)
            switch result {
            case .success(let value):
                if let json = value as? [String: Any] {
                    if let aSubKey = subKey {
                        if let newValue = json[aSubKey] as? [String: Any] {
                            return .success(newValue)
                        } else {
                            return .success(json[aSubKey] as Any)
                        }
                    } else {
                        return .success(json)
                    }
                }
                
                return .failure(ServiceError.undefined)
            case .failure(let error):
                return .failure(error)
            }
        })
    }
}

extension DataRequest {
    @discardableResult
    public func responseAnyObject(subKey: String? = nil, queue: DispatchQueue? = nil) -> Promise<Any> {
        return Promise { seal in
            let _ = response(queue: queue, responseSerializer: BaseClient.responseObjectSerializer(subKey: subKey)) { (response: DataResponse<Any>) in
                switch response.result {
                case .success(let value):
                    seal.fulfill(value)
                case .failure(let error):
                    seal.reject(error)
                }
            }
        }
    }
}


