//
//  AudioPlayerHelper.swift
//  PicTranslate
//
//  Created by Duong on 1/11/20.
//  Copyright © 2020 Duong. All rights reserved.
//

import AVFoundation
import AVKit
import Alamofire

class AudioPlayerHelper {
    
    static let shared = AudioPlayerHelper()
    private var player: AVAudioPlayer?
    
    func playAudio(word : String, lang : String) {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            print("audioSession properties weren't set because of an error.")
        }
        
        // Tao file name
        var file_name = word
        file_name = file_name.lowercased()
        file_name = file_name.replacingOccurrences(of: " ", with: "+")
        file_name = file_name.replacingOccurrences(of: "\n", with: ".")
        
        var urlComponents = URLComponents(string: "https://translate.google.com/translate_tts")!
        var queryItems = [URLQueryItem]()
        queryItems.append(URLQueryItem(name: "q", value: file_name))
        queryItems.append(URLQueryItem(name: "tk", value: "283800"))
        queryItems.append(URLQueryItem(name: "client", value: "tw-ob"))
        queryItems.append(URLQueryItem(name: "total", value: "1"))
        queryItems.append(URLQueryItem(name: "idx", value: "0"))
        queryItems.append(URLQueryItem(name: "tl", value: lang))
        queryItems.append(URLQueryItem(name: "textLen", value: "\(file_name.lengthOfBytes(using: .utf8))"))
        urlComponents.queryItems = queryItems
        
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as String
        let url = URL(fileURLWithPath: path)
        
        let filePath = url.appendingPathComponent("audio.mp3")
        
        if player == nil {
            self.load(url: urlComponents.url!, to: filePath, completion: { (isSuccess) in
               if isSuccess {
                   self.play(url: filePath)
               }
            })
        } else {
            if player!.isPlaying {
                player?.stop()
            } else {
                self.load(url: urlComponents.url!, to: filePath, completion: { (isSuccess) in
                   if isSuccess {
                       self.play(url: filePath)
                   }
                })
            }
        }
    }
    
    private func play(url: URL) {
        DispatchQueue.main.async {
            do {
                let sPlayer = try AVAudioPlayer(contentsOf: url)
                self.player = sPlayer
                self.player?.prepareToPlay()
                self.player?.enableRate = true
                self.player?.rate = 1.0
                self.player?.play()
            } catch let error {
                print(error.localizedDescription)
            }
        }
    }
    
    private func load(url: URL, to localUrl: URL, completion: @escaping (_ isSuccess : Bool) -> ()) {
        var urlRequest = URLRequest(url: url)
        urlRequest.addValue("Mozilla/5.0 (X11; Linux x86_64; rv:12.0) Gecko/20100101 Firefox/12.0", forHTTPHeaderField: "User-Agent")
        urlRequest.timeoutInterval = 10.0
        
        let task = URLSession.shared.downloadTask(with: urlRequest) { (tempLocalUrl, response, error) in
            if let tempLocalUrl = tempLocalUrl, error == nil {
                // Success
                if let statusCode = (response as? HTTPURLResponse)?.statusCode {
                    print("Success: \(statusCode)")
                }
                
                if FileManager.default.fileExists(atPath: localUrl.path) {
                    //print("DELETE FILE EXIST")
                    do {
                        try FileManager.default.removeItem(atPath: localUrl.path)
                    }catch {
                        return
                    }
                    
                }
                
                do {
                    try FileManager.default.copyItem(at: tempLocalUrl, to: localUrl)
                    completion(true)
                } catch (let writeError) {
                    completion(false)
                    print("error writing file \(localUrl) : \(writeError)")
                }
                
            } else {
                completion(false)
            }
        }
        task.resume()
    }
}
