//
//  DataManager.swift
//  PicTranslate
//
//  Created by Duong on 1/10/20.
//  Copyright © 2020 Duong. All rights reserved.
//

import UIKit
import RealmSwift

let documentPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].path

class DataManager: NSObject {
    let realm = try! Realm()
    static let shared = DataManager()
    
    func getAllHistory() -> [HistoryModel] {
        return Array(self.realm.objects(HistoryModel.self))
    }
    
    func saveData(data: HistoryModel) {
        try! self.realm.write {
            self.realm.add(data, update: .all)
        }
    }
    
    func deleteData(data: HistoryModel) {
        try! self.realm.write {
            self.realm.delete(data)
       }
    }
    
    func saveImageDocumentDirectory(image: UIImage, content: String, completeBlock: @escaping (_ data: HistoryModel) -> Void) {
        let fileManager = FileManager.default
        
        let dataOutput = HistoryModel()
        dataOutput.id = UUID().uuidString
        
        let imageName = dataOutput.id + ".png"
        let imagePath = documentPath + "/\(imageName)"

        let imageData = image.jpegData(compressionQuality: 1.0)
        fileManager.createFile(atPath: imagePath, contents: imageData, attributes: nil)
        print(imagePath)
        
//        if let thumbImage = image.createThumbImage(width: 500) {
//            let thumbData = thumbImage.jpegData(compressionQuality: 1.0)
//            fileManager.createFile(atPath: imagePath, contents: thumbData, attributes: nil)
//            print(imagePath)
//        }
        
        dataOutput.fileName = imageName
        dataOutput.content = content
        dataOutput.timeUpdate = Int(Date().timeIntervalSince1970 * 1000)
        
        completeBlock(dataOutput)
    }
    
    func deleteFile(path: String, complete: @escaping () -> ()) {
        do {
            let fileManager = FileManager.default
            if fileManager.fileExists(atPath: path) {
                try fileManager.removeItem(atPath: path)
                complete()
            } else {
                print("File not exist")
            }
        } catch let error as NSError {
            print("An error took place: \(error)")
        }
    }
    
}
