//
//  PicTranslate-Bridging-Header.h
//  PicTranslate
//
//  Created by Duong on 1/9/20.
//  Copyright © 2020 Duong. All rights reserved.
//

#ifndef PicTranslate_Bridging_Header_h
#define PicTranslate_Bridging_Header_h

#import "CameraSessionView.h"
#import "G8RecognitionOperation.h"

#endif /* PicTranslate_Bridging_Header_h */
