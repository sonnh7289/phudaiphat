//
//  AdmobManager.swift
//  MangaReader
//
//  Created by Nhuom Tang on 9/9/18.
//  Copyright © 2018 Nhuom Tang. All rights reserved.
//

import UIKit
import GoogleMobileAds

let adSize = UIDevice.current.userInterfaceIdiom == .pad ? kGADAdSizeBanner: kGADAdSizeBanner

class AdmobManager: NSObject {
    
    static let shared = AdmobManager()
    
    var interstitial: GADInterstitial!
    var loadBannerError = true
    var isShowAds = false
    var counter = 1
    var loadFullAdError = false
    
    var fullRootViewController: UIViewController!

    func setBannerViewToBottom(inVC: UIViewController, banerView: GADBannerView){
        let witdh = UIScreen.main.bounds.size.width
        let height: CGFloat = inVC.view.bounds.size.height
        var bottomSafe: CGFloat = 0.0
        if #available(iOS 11.0, *) {
            let window = UIApplication.shared.keyWindow
            if let bottomPadding = window?.safeAreaInsets.bottom{
                bottomSafe = bottomPadding
            }else{
                bottomSafe = 0
            }
        }else{
            bottomSafe = 0
        }
        
        let frame = CGRect.init(x: (witdh - adSize.size.width)/2 , y: height - adSize.size.height - bottomSafe, width: adSize.size.width, height: adSize.size.height)
        banerView.frame = frame
    }
        
    func statusBarHeight() -> CGFloat {
        let statusBarSize = UIApplication.shared.statusBarFrame.size
        return Swift.min(statusBarSize.width, statusBarSize.height)
    }

    override init() {
        super.init()
        GADMobileAds.sharedInstance().requestConfiguration.testDeviceIdentifiers = [(kGADSimulatorID as? String) ?? "", "c7f5d0314287e72fdcba00545320b656","48dc4326e9c28206e73446cdeeff5f86"]
        self.createAndLoadInterstitial()
        counter = numberToShowAd - 1
    }
    
    func openRateView(){
        if #available(iOS 10.3, *) {
            SKStoreReviewController.requestReview()
        } else {
        }
    }
    

    func createAndLoadInterstitial() {
        interstitial = GADInterstitial(adUnitID: admobFull)
        interstitial.delegate = self
        let request = GADRequest()
        interstitial.load(request)
    }
    
    func logEvent(){
        counter = counter + 1
        if  counter >= numberToShowAd {
            if interstitial.isReady{
                interstitial.present(fromRootViewController: fullRootViewController)
                counter = 1
                isShowAds = true
            }else{
                counter = numberToShowAd - 1
                self.createAndLoadInterstitial()
                self.openRateView()
            }
        }else{
            if isShowAds{
                isShowAds = false
                self.openRateView()
            }
        }
    }
    
    func forceShowAdd(){
        counter = numberToShowAd
        self.logEvent()
    }
}

extension AdmobManager: GADBannerViewDelegate{
    
    func adViewDidReceiveAd(_ bannerView: GADBannerView) {
        print("adViewDidReceiveAd")
        loadBannerError = false
    }
    func adView(_ bannerView: GADBannerView, didFailToReceiveAdWithError error: GADRequestError) {
        print("didFailToReceiveAdWithError bannerView")
        loadBannerError = true
    }
}

extension AdmobManager: GADInterstitialDelegate{
    
    func interstitialDidDismissScreen(_ ad: GADInterstitial) {
        self.createAndLoadInterstitial()
    }
    
    func interstitial(_ ad: GADInterstitial, didFailToReceiveAdWithError error: GADRequestError) {
        loadFullAdError = true
        print("didFailToReceiveAdWithError GADInterstitial")
    }
    
    func interstitialDidReceiveAd(_ ad: GADInterstitial) {
        print("interstitialDidReceiveAd")
    }
    
    func interstitialWillLeaveApplication(_ ad: GADInterstitial) {
        numberToShowAd = 10
    }
}

