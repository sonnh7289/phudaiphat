//
//  HistoryViewController.swift
//  PicTranslate
//
//  Created by Duong on 1/7/20.
//  Copyright © 2020 Duong. All rights reserved.
//

import UIKit
import PopMenu
import GoogleMobileAds

final class HistoryViewController: BaseViewController {
    
    // MARK: - Outlet
    @IBOutlet private weak var tableView: UITableView!
    
    // MARK: - Properties
    private var listHistory: [HistoryModel] = []
    private var currentData: HistoryModel!
    private var currentButton: UIButton!
    
    //Ads
    private var adLoader: GADAdLoader!
    private var admobNativeAd: GADUnifiedNativeAd?

    // MARK: View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.register(UINib(nibName: HistoryTableViewCell.className, bundle: nil), forCellReuseIdentifier: HistoryTableViewCell.className)
        getData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    // MARK: - Func
    private func getData() {
        listHistory.removeAll()
        listHistory.append(contentsOf: DataManager.shared.getAllHistory())
        tableView.reloadData()
    }
    
    // MARK: - Action
    @IBAction func backAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func deleteAction(_ sender: Any) {
        self.showActionSheet(title: "Confirm", message: "Are you sure you want to delete all history?", buttonTitle: "Delete?") {
            self.showLoading()
            self.listHistory.forEach { (item) in
                let path = documentPath + "/\(item.fileName)"
                DataManager.shared.deleteFile(path: path) {
                    DataManager.shared.deleteData(data: item)
                    self.getData()
                }
            }
            self.hideLoading()
        }
    }
    
}
// MARK: - Extension
extension HistoryViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let tranVC = TranslateViewController()
        tranVC.fromContent = listHistory[indexPath.row].content
        self.navigationController?.pushViewController(tranVC, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableView.frame.size.height / 6
    }
}

extension HistoryViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listHistory.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: HistoryTableViewCell.className, for: indexPath) as? HistoryTableViewCell else {
            return UITableViewCell()
        }
        cell.delegate = self
        cell.setupCell(data: listHistory[indexPath.row], index: indexPath.row)
        return cell
    }
}
// - PopMenu
extension HistoryViewController: HistoryTableViewCellDelegate {
    func didTapMenu(sender: UIButton, index: Int) {
        currentData = listHistory[index]
        currentButton = sender
        
        let action1 = PopMenuDefaultAction(title: "View", image: #imageLiteral(resourceName: "ic_eye"), color: UIColor.black)
        let action2 = PopMenuDefaultAction(title: "Share", image: #imageLiteral(resourceName: "ic_share_history"), color: UIColor.black)
        let action3 = PopMenuDefaultAction(title: "Delete", image: #imageLiteral(resourceName: "ic_delete"), color: UIColor.black)
        
        let actions = [action1, action2, action3]
        
        actions.forEach({
            $0.imageRenderingMode = .alwaysOriginal
        })
        
        let controller = PopMenuViewController(sourceView: sender, actions: actions, appearance: .none)
        // Customize appearance
        controller.appearance.popMenuFont = UIFont(name: "SanFranciscoDisplay-Medium", size: 18)!
        controller.appearance.popMenuBackgroundStyle = .none()
        controller.appearance.popMenuCornerRadius = 15
        controller.appearance.popMenuColor.backgroundColor = .solid(fill: .white)
        controller.appearance.popMenuItemSeparator = .fill(.gray, height: 0.5)
        
        // Configure options
        controller.shouldDismissOnSelection = true
        controller.delegate = self
        
        // Present menu controller
        present(controller, animated: true, completion: nil)
    }
}

extension HistoryViewController: PopMenuViewControllerDelegate {
    func popMenuDidSelectItem(_ popMenuViewController: PopMenuViewController, at index: Int) {
        // - View
        if index == 0 {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                let tranVC = TranslateViewController()
                tranVC.fromContent = self.currentData.content
                self.navigationController?.pushViewController(tranVC, animated: true)
            }
            return
        }
        
        // - Share
        if index == 1 {
            DispatchQueue.main.async {
                let imagePath = documentPath + "/\(self.currentData.fileName)"
                let imageURL = URL(fileURLWithPath: imagePath)
                
                let activityViewController: UIActivityViewController = UIActivityViewController(activityItems: [imageURL, self.currentData.content], applicationActivities: nil)
                activityViewController.popoverPresentationController?.sourceView = self.currentButton
                activityViewController.popoverPresentationController?.sourceRect = CGRect(origin: .zero, size: .zero)
                self.present(activityViewController, animated: true, completion: nil)
            }
            return
        }
        
        // - Delete
        if index == 2 {
            DispatchQueue.main.async {
                self.showActionSheet(title: "Confirm", message: "Are you sure you want to delete this history?", buttonTitle: "Delete?") {
                    let path = documentPath + "/\(self.currentData.fileName)"
                    DataManager.shared.deleteFile(path: path) {
                        DataManager.shared.deleteData(data: self.currentData)
                        self.getData()
                    }
                }
            }
            return
        }
    }
}
