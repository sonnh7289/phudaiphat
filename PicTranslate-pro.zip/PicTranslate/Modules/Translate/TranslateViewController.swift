//
//  TranslateViewController.swift
//  PicTranslate
//
//  Created by Duong on 1/7/20.
//  Copyright © 2020 Duong. All rights reserved.
//

import UIKit
import Toast_Swift
import GoogleMobileAds

final class TranslateViewController: BaseViewController {
    // MARK: - Outlet
    @IBOutlet private weak var fromTextView: UITextView!
    @IBOutlet private weak var heightFromTextView: NSLayoutConstraint!
    @IBOutlet private weak var toTextView: UITextView!
    @IBOutlet private weak var heightToTextView: NSLayoutConstraint!
    @IBOutlet private weak var fromLbl: UILabel!
    @IBOutlet private weak var toLbl: UILabel!
    @IBOutlet weak var viewShowNative: UIView!
    @IBOutlet weak var nativeAdsHeight: NSLayoutConstraint!

    // MARK: - Properties
    var fromContent: String = ""
    
    private var currentShortLangFrom: String = ""
    private var currentShortLangTo: String = ""
    
    //Ads
    private var adLoader: GADAdLoader!
    private var admobNativeAd: GADUnifiedNativeAd?

    // MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        toTextView.isEditable = false
        
        fillDataFromTextView(txt: fromContent)
        fillDataToTextView(txt: "")
        
        dectectDeviceLang()
        if fromContent.count > 0{
            delectFromLang(content: fromContent)
        }
        nativeAdsHeight.constant = 0
        view.layoutIfNeeded()

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        viewShowNative.isHidden = false
    }
    
    // MARK: - Func
    private func fillDataFromTextView(txt: String) {
        self.fromTextView.text = txt.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: "\n\n", with: "\n")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.heightFromTextView.constant = self.fromTextView.contentSize.height
        }
    }
    
    private func fillDataToTextView(txt: String) {
        DispatchQueue.main.async {
            self.toTextView.text = txt.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: "\n\n", with: "\n")
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.heightToTextView.constant = self.toTextView.contentSize.height
        }
    }
    
    private func delectFromLang(content: String) {
        showLoading()
        let formatStr = content.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: "\n\n", with: "\n")
        
        if StorageManager.getStringForkey(key: KEY_FROM_LANG_SHORT) == "" {
            
            BaseClient.shared.detectLang(text: formatStr, completion: { response in
                if let response = response {
                    if let _fromLang = langSupportDicts[response] {
                        DispatchQueue.main.async {
                            self.fromLbl.text = _fromLang
                            self.currentShortLangFrom = response
                        }
                    } else {
                        DispatchQueue.main.async {
                            self.fromLbl.text = "English"
                            self.currentShortLangFrom = "en"
                        }
                    }
                }
                
                DispatchQueue.main.async {
                    self.hideLoading()
                    self.translate(text: formatStr, from: self.currentShortLangFrom, to: self.currentShortLangTo)
                }
            })
            
        } else {
            fromLbl.text = StorageManager.getStringForkey(key: KEY_FROM_LANG_FULL)
            currentShortLangFrom = StorageManager.getStringForkey(key: KEY_FROM_LANG_SHORT)
            
            DispatchQueue.main.async {
                self.translate(text: formatStr, from: self.currentShortLangFrom, to: self.currentShortLangTo)
            }
        }
    }
    
    private func dectectDeviceLang() {
        if StorageManager.getStringForkey(key: KEY_TO_LANG_SHORT) == "" {
            let preferredLanguage = Locale.preferredLanguages[0] as String
            let arr = preferredLanguage.components(separatedBy: "-")
            let deviceLanguage = arr.first
            
            if let _toLang = langSupportDicts[deviceLanguage ?? "en"] {
                toLbl.text = _toLang
                currentShortLangTo = deviceLanguage ?? "en"
            } else {
                toLbl.text = "English"
                currentShortLangTo = "en"
            }
        } else {
            toLbl.text = StorageManager.getStringForkey(key: KEY_TO_LANG_FULL)
            currentShortLangTo = StorageManager.getStringForkey(key: KEY_TO_LANG_SHORT)
        }
    }
    
    private func translate(text: String, from: String, to: String) {
        toTextView.text = ""
        let formatStr = text.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: "\n\n", with: "\n")
        if formatStr != "" {
            BaseClient.shared.translate(text: formatStr, from: from, to: to) { response in
                if let res = response {
                    self.fillDataToTextView(txt: res)
                } else {
                    self.fillDataToTextView(txt: "Cannot translate!")
                }
                DispatchQueue.main.async {
                    self.hideLoading()
                }
            }
//            BaseClient.shared.translate(text: formatStr, from: from, to: to).done { (response) in
//                if let result = response as? [String] {
//                    self.fillDataToTextView(txt: result[0])
//                }
//                self.hideLoading()
//            }.catch { (error) in
//                self.hideLoading()
//                print(error)
//            }
        } else {
            hideLoading()
        }
    }
    
     // MARK: - Action
    @IBAction func backAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func changeLanguageAction(_ sender: Any) {
        let button = sender as! UIButton
    
        let langVC = LanguageViewController()
        langVC.modalPresentationStyle = .fullScreen
        // - 0: From
        if button.tag == 0 {
            langVC.isFromLang = true
            langVC.currentShortLang = currentShortLangFrom
        }
        
        // - 1: To
        if button.tag == 1 {
            langVC.isFromLang = false
            langVC.currentShortLang = currentShortLangTo
        }
        present(langVC, animated: true, completion: nil)
        
        // - Call Back
        langVC.didChangeLang = {[weak self] (isFrom, fullName, shortName) in
            if isFrom {
                self?.currentShortLangFrom = shortName
                self?.fromLbl.text = fullName
                
                // - Save From
                StorageManager.setString(value: shortName, forKey: KEY_FROM_LANG_SHORT)
                StorageManager.setString(value: fullName, forKey: KEY_FROM_LANG_FULL)
                
            } else {
                self?.currentShortLangTo = shortName
                self?.toLbl.text = fullName
                
                // - Save To
                StorageManager.setString(value: shortName, forKey: KEY_TO_LANG_SHORT)
                StorageManager.setString(value: fullName, forKey: KEY_TO_LANG_FULL)
                
                self?.showLoading()
                self?.translate(text: self?.fromTextView.text ?? "", from: self!.currentShortLangFrom, to: self!.currentShortLangTo)
            }
        }
    }
    
    @IBAction func translateAction(_ sender: Any) {
        if fromTextView.text != "" {
            showLoading()
            translate(text: fromTextView.text ?? "", from: currentShortLangFrom, to: currentShortLangTo)
        }
    }
    
    @IBAction func speakAction(_ sender: Any) {
        let button = sender as! UIButton
        // - 0: From
        if button.tag == 0 {
            if fromTextView.text != "" {
                AudioPlayerHelper.shared.playAudio(word: fromTextView.text, lang: currentShortLangFrom)
            }
            return
        }
        
        // - 1: To
        if button.tag == 1 {
            if toTextView.text != "" {
                AudioPlayerHelper.shared.playAudio(word: toTextView.text, lang: currentShortLangTo)
            }
            return
        }
    }
    
    @IBAction func copyAction(_ sender: Any) {
        let button = sender as! UIButton
        // - 0: From
        if button.tag == 0 {
            if fromTextView.text != "" {
                self.view.makeToast("Copy to clipboard", duration: 1.0, position: .top)
                UIPasteboard.general.string = fromTextView.text
            }
            return
        }
        
        // - 1: To
        if button.tag == 1 {
            if toTextView.text != "" {
                self.view.makeToast("Copy to clipboard", duration: 1.0, position: .top)
                UIPasteboard.general.string = toTextView.text
            }
            return
        }
    }
}
extension TranslateViewController: UITextViewDelegate {
    func textViewDidBeginEditing(_ textView: UITextView) {
        DispatchQueue.main.async {
            textView.selectAll(nil)
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text != "" {
            showLoading()
            translate(text: fromTextView.text ?? "", from: currentShortLangFrom, to: currentShortLangTo)
        } else {
            toTextView.text = ""
        }
    }
}
