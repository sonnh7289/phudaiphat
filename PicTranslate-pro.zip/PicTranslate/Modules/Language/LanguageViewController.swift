//
//  LanguageViewController.swift
//  PicTranslate
//
//  Created by Duong on 1/7/20.
//  Copyright © 2020 Duong. All rights reserved.
//

import UIKit

final class LanguageViewController: BaseViewController {
    // MARK: - Outlet
    @IBOutlet private weak var tableView: UITableView!
    
    // MARK: - Properties
    var currentShortLang: String = ""
    var isFromLang: Bool = true
    var didChangeLang: ((_ isFrom: Bool, _ fullName: String, _ shortName: String) -> Void)?
    
    private var currentFullLang: String = ""
    private var indexSelected: Int = 0
    
    private var listLangSort = [(key: String, value: String)]()
    private var listShortName: [String] = []
    private var listFullName: [String] = []
    
    // MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        hideKeyboardWhenTappedAround()
        tableView.tableFooterView = UIView()
        tableView.register(UINib(nibName: LanguageTableViewCell.className, bundle: nil), forCellReuseIdentifier: LanguageTableViewCell.className)
        getData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        DispatchQueue.main.async {
//            self.tableView.scrollToRow(at: IndexPath(row: self.indexSelected, section: 0), at: .middle, animated: false)
        }
    }
    
    private func getData() {
        if !langSupportDicts.isEmpty {
            listFullName.removeAll()
            listShortName.removeAll()
            listLangSort = langSupportDicts.sorted { $0.value < $1.value }
            
            listLangSort.forEach { (key, value) in
                listShortName.append(key)
                listFullName.append(value)
            }
            tableView.reloadData()
            
            for i in 0..<listLangSort.count {
                if currentShortLang == Array(listLangSort)[i].key {
                    indexSelected = i
                    currentShortLang = Array(listLangSort)[i].key
                    currentFullLang = Array(listLangSort)[i].value
                }
            }
        }
    }
    
    // MARK: - Action
    @IBAction func backAction(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func doneAction(_ sender: Any) {
        if currentShortLang != "" && currentFullLang != "" {
            dismiss(animated: true) {[weak self] in
                self?.didChangeLang?(self!.isFromLang, self!.currentFullLang, self!.currentShortLang)
            }
        }
    }
}
// MARK: - Extensions

// - Search Bar
extension LanguageViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        let dictTemps = langSupportDicts.filter { (key, value) -> Bool in
            if searchText == "" {
                return true
            } else {
                return value.contains(searchText)
            }
        }.sorted { $0.value < $1.value }
        
        listFullName.removeAll()
        listShortName.removeAll()
        dictTemps.forEach { (key, value) in
            self.listShortName.append(key)
            self.listFullName.append(value)
        }
        tableView.reloadData()
    }
}

// - TableView
extension LanguageViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        currentShortLang = listShortName[indexPath.row]
        currentFullLang = listFullName[indexPath.row]
        tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}

extension LanguageViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listFullName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: LanguageTableViewCell.className, for: indexPath) as? LanguageTableViewCell else {
            return UITableViewCell()
        }
        cell.setupCell(shortName: listShortName[indexPath.row], fullName: listFullName[indexPath.row], isSelected: currentShortLang == listShortName[indexPath.row])
        return cell
    }
}
