//
//  Constant.swift
//  BitEclipse
//
//  Created by Nhuom Tang on 24/4/19.
//  Copyright © 2019 Nhuom Tang. All rights reserved.
//

import UIKit
import Alamofire

typealias AppResult = Result

let API_KEY = "trnsl.1.1.20170425T085917Z.580fec9ed721d387.9caf5bd2514ca1581b95de321974dce826ef5064"

//VALUE
let DEVICE_WIDTH = UIScreen.main.bounds.width
let DEVICE_HEIGHT = UIScreen.main.bounds.height
let IS_IPAD = UIDevice.current.userInterfaceIdiom == .pad

let KEY_FROM_LANG_FULL = "KEY_FROM_LANG_FULL"
let KEY_FROM_LANG_SHORT = "KEY_FROM_LANG_SHORT"
let KEY_TO_LANG_FULL = "KEY_TO_LANG_FULL"
let KEY_TO_LANG_SHORT = "KEY_TO_LANG_SHORT"

var langSupportDicts: [String: String] = [:]

