//
//  Config.swift
//  BitEclipse
//
//  Created by Nhuom Tang on 23/4/19.
//  Copyright © 2019 Nhuom Tang. All rights reserved.
//

import Foundation

let appid = "1494559997"
let mailSupport = "suntectltd.software@gmail.com"

let admobFull = "ca-app-pub-7204820750600293/9514198608"
var numberToShowAd = 5
