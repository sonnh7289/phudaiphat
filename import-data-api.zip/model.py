import json
import mysql.connector

HOST = "localhost"
USER = "root"
PASSWD = ""
DB = "myanimelist"

Anime_Manga_News = r"D:\Code Python\ThinkDiff\sql_anime_manga\data\Anime_Manga_News.json"
Comment_News = r"D:\Code Python\ThinkDiff\sql_anime_manga\data\Comment_News.json"
Reviews_Anime = r"D:\Code Python\ThinkDiff\sql_anime_manga\data\Reviews_Anime.json"
Reviews_Manga = r"D:\Code Python\ThinkDiff\sql_anime_manga\data\Reviews_Manga.json"
Reviews_Top_Anime = r"D:\Code Python\ThinkDiff\sql_anime_manga\data\Reviews_Top_Anime.json"
Reviews_Top_Manga = r"D:\Code Python\ThinkDiff\sql_anime_manga\data\Reviews_Top_Manga.json"
Top_Anime = "D:\Code Python\ThinkDiff\sql_anime_manga\data\Top_Anime.json"
Top_Manga = r"D:\Code Python\ThinkDiff\sql_anime_manga\data\Top_Manga.json"



def get_data_json(_LINK_JSON_FILE):
    with open(_LINK_JSON_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data
