//
//  AppDelegate.swift
//  PicTranslate
//
//  Created by Duong on 1/6/20.
//  Copyright © 2020 Duong. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift
import GoogleMobileAds
import SwiftGoogleTranslate

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
          
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        GADMobileAds.sharedInstance().start(completionHandler: nil)

        configMainWindow()
        IQKeyboardManager.shared.enable = true
        
        SwiftGoogleTranslate.shared.start(with: "AIzaSyBydOS43_cJRVva43LOMN5Fx4iaXMjiWBs")
        
        BaseClient.shared.getAllLanguageSupport { results in
            langSupportDicts = results
        }
      
        return true
    }
      
    private func configMainWindow() {
        self.window = UIWindow(frame: UIScreen.main.bounds)
        self.window?.backgroundColor = .white
        self.window?.rootViewController = creatRootViewController()
        self.window?.makeKeyAndVisible()
        AdmobManager.shared.fullRootViewController = self.window?.rootViewController
    }

    private func creatRootViewController() -> UINavigationController {
        var rootViewController = UIViewController()
        rootViewController = HomeViewController.init(nibName: String(describing: HomeViewController.self).nibWithNameiPad(), bundle: nil)
        let navigationViewController = UINavigationController(rootViewController: rootViewController)
        navigationViewController.isNavigationBarHidden = true
        return navigationViewController
    }

}

