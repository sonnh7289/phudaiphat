//
//  HistoryModel.swift
//  PicTranslate
//
//  Created by Duong on 1/10/20.
//  Copyright © 2020 Duong. All rights reserved.
//

import UIKit
import RealmSwift

class HistoryModel: Object {
    @objc dynamic var id: String = ""
    @objc dynamic var fileName: String = ""
    @objc dynamic var content: String = ""
    @objc dynamic var timeUpdate: Int = 0
    override static func primaryKey() -> String? {
        return "id"
    }
}
