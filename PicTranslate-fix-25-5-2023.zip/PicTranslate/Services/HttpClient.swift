//
//  HttpClient.swift
//  BitEclipse
//
//  Created by Nhuom Tang on 24/4/19.
//  Copyright © 2019 Nhuom Tang. All rights reserved.
//

import Foundation
import Alamofire
import PromiseKit
import SwiftGoogleTranslate

extension BaseClient{
  
    func getAllLanguageSupport(completion: @escaping ([String: String]) -> Void) {
        var results: [String: String] = [:]
        SwiftGoogleTranslate.shared.languages { (languages, error) in
            if let languages = languages {
                for language in languages {
                    print(language.language)
                    print(language.name)
                    print("---")
                    results.updateValue(language.name, forKey: language.language)
                }
                completion(results)
            } else {
                completion([:])
            }
        }
        
        
        
       
//        let params: Parameters = ["key":API_KEY, "ui":"en"]
//        return request(.post, "getLangs", parameters: params, encoding: URLEncoding.default).responseAnyObject(subKey: "langs")
    }
    
    
    
    func detectLang(text: String, completion: @escaping (String?) -> Void) {
        SwiftGoogleTranslate.shared.detect(text) { (detections, error) in
            if let detections = detections {
                for detection in detections {
                    print(detection.language)
                    print(detection.isReliable)
                    print(detection.confidence)
                    print("---")
                    completion(detection.language)
                    break
                }
            }
            completion(nil)
        }
        
//        let params: Parameters = ["key":API_KEY, "text":text]
//        return request(.post, "detect", parameters: params, encoding: URLEncoding.default).responseAnyObject(subKey: "lang")
    }
    
    func translate(text: String, from: String, to: String, completion: @escaping (String?) -> Void) {
        SwiftGoogleTranslate.shared.translate(text, to, from) { (text, error) in
            if let t = text {
                print(t)
                completion(t)
            } else {
                completion(nil)
            }
            
        }
        
//        let params: Parameters = ["key": API_KEY, "text": text, "lang": "\(from)-\(to)"]
//        return request(.post, "translate", parameters: params, encoding: URLEncoding.default).responseAnyObject(subKey: "text")
    }
}
