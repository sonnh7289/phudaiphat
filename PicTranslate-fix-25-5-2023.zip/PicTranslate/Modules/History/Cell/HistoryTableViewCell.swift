//
//  HistoryTableViewCell.swift
//  PicTranslate
//
//  Created by Duong on 1/7/20.
//  Copyright © 2020 Duong. All rights reserved.
//

import UIKit

protocol HistoryTableViewCellDelegate: class {
    func didTapMenu(sender: UIButton, index: Int)
}

final class HistoryTableViewCell: UITableViewCell {
    @IBOutlet private weak var imageThumb: UIImageView!
    @IBOutlet private weak var contentLbl: UILabel!
    @IBOutlet private weak var timeLbl: UILabel!
    
    weak var delegate : HistoryTableViewCellDelegate?
    private var indexSelected: Int = 0
    
    
    func setupCell(data: HistoryModel, index: Int) {
        indexSelected = index
        contentLbl.text = data.content
        
        let path = documentPath + "/\(data.fileName)"
        let image = UIImage(contentsOfFile: path)
        imageThumb.image = image
        
        timeLbl.text = convertTime(time: data.timeUpdate) + "'"
    }
    
    private func convertTime(time: Int) -> String {
        guard let timeInterval = TimeInterval(exactly: time) else { return "" }
        let exactDate = NSDate(timeIntervalSince1970: timeInterval / 1000)
        let dateFormatt = DateFormatter()
        dateFormatt.dateFormat = "dd-MM-yyy    hh:mm"
        return dateFormatt.string(from: exactDate as Date)
    }
    
    @IBAction func didSelectMoreAction(_ sender: Any) {
        if delegate != nil {
            delegate?.didTapMenu(sender: sender as! UIButton, index: indexSelected)
        }
    }
}
