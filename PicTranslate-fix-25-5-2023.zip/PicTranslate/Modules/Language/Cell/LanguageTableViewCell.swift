//
//  LanguageTableViewCell.swift
//  PicTranslate
//
//  Created by Duong on 1/7/20.
//  Copyright © 2020 Duong. All rights reserved.
//

import UIKit

final class LanguageTableViewCell: UITableViewCell {
    @IBOutlet private weak var ensignImage: UIImageView!
    @IBOutlet private weak var langLbl: UILabel!
    
    func setupCell(shortName: String, fullName: String, isSelected: Bool) {
        if let image = UIImage(named: "flag_" + shortName) {
            ensignImage.image = image
        } else {
            ensignImage.image = UIImage(named: "default")
        }
        langLbl.text = fullName + "-" + shortName
        self.backgroundColor = isSelected ? UIColor(named: "Blue") : .clear
    }
}
