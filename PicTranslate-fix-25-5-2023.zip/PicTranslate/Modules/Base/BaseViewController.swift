//
//  BaseViewController.swift
//  PicTranslate
//
//  Created by Duong on 1/7/20.
//  Copyright © 2020 Duong. All rights reserved.
//

import UIKit

class BaseViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavigation()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    private func setupNavigation() {
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.navigationBar.barTintColor = UIColor.white
        self.navigationController?.navigationBar.tintColor = UIColor.black
        self.navigationController?.navigationBar.shadowImage = UIImage()
        
        if  IS_IPAD {
            self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor : UIColor.black,
                                                 NSAttributedString.Key.font: UIFont(name: "SanFranciscoDisplay-Medium", size: 21)!]
        }else{
            self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor :UIColor.black,
                                                 NSAttributedString.Key.font: UIFont(name: "SanFranciscoDisplay-Medium", size: 21)!]
        }
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return .lightContent
    }
}
