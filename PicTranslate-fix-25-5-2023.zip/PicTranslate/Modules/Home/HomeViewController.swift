//
//  HomeViewController.swift
//  PicTranslate
//
//  Created by Duong on 1/6/20.
//  Copyright © 2020 Duong. All rights reserved.
//

import UIKit
import Toast_Swift
import MessageUI
import CRNotifications

final class HomeViewController: BaseViewController {

    @IBOutlet private weak var adsView: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()
        MenuViewController.shared.delegate = self
    }
    
    private func openCamera() {
        let camVC = CameraViewController()
        let camNV = UINavigationController(rootViewController: camVC)
        camNV.modalPresentationStyle = .overFullScreen
        self.present(camNV, animated: true, completion: nil)
        
        camVC.pushToViewController = {[weak self] (contentStr) in
            if contentStr == "" {
                self?.view.makeToast("No content was found", duration: 1.5, position: .top)
            } else {
                let tranVC = TranslateViewController()
                tranVC.fromContent = contentStr
                self?.navigationController?.pushViewController(tranVC, animated: true)
            }
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    // MARK: - Action
    @IBAction func selectItemAction(_ sender: Any) {
        let button = sender as! UIButton
        switch button.tag {
        case 0:
            openCamera()
            break
        case 1:
            let tranVC = TranslateViewController()
            navigationController?.pushViewController(tranVC, animated: true)
            AdmobManager.shared.forceShowAdd()
            break
        case 2:
            let historyVC = HistoryViewController()
            navigationController?.pushViewController(historyVC, animated: true)
            break
        default:
            break
        }
    }
    
    @IBAction func takePhotoAction(_ sender: Any) {
        openCamera()
    }
    
    
    @IBAction func selectMenuAction(_ sender: Any) {
        MenuViewController.shared.show()
    }
    
}
// MARK: - Extension
// - Menu Delegate
extension HomeViewController : MenuViewDelegate {
    func didSelectRowAt(index: Int) {
        if index == MenuType.Policy.rawValue {
            let policyVC = PolicyViewController()
            self.navigationController?.pushViewController(policyVC, animated: true)
            
        } else if index == MenuType.About.rawValue{
            let aboutVC = AboutViewController()
            self.navigationController?.pushViewController(aboutVC, animated: true)
        } else if index == MenuType.Support.rawValue{
            if MFMailComposeViewController.canSendMail() {
                let mail = MFMailComposeViewController()
                mail.mailComposeDelegate = self
                mail.setToRecipients([mailSupport])
                mail.setSubject("Regarding Ringtone Maker")
                present(mail, animated: true)
            } else {
                self.showCusomToast(title: "", message: "Mail services are not available", dismissDelay: 3, type: CRNotifications.error)
            }
            
        } else if index == MenuType.Share.rawValue{
            let text = [ "https://apps.apple.com/app/id" + appid ]
            let activityViewController = UIActivityViewController(activityItems: text , applicationActivities: nil)
            activityViewController.popoverPresentationController?.sourceView = self.view
            activityViewController.popoverPresentationController?.sourceRect = CGRect(origin: self.view.center, size: .zero)
            self.present(activityViewController, animated: true, completion: nil)
            
        } else if index == MenuType.Rate.rawValue{
            let text = "https://apps.apple.com/app/id" + appid
            if let url = URL.init(string: text){
                if UIApplication.shared.canOpenURL(url){
                    UIApplication.shared.open(url, options: [:], completionHandler: nil)
                }
            }
        }
    }
}

//MARK: -- MFMailComposeViewControllerDelegate
extension HomeViewController: MFMailComposeViewControllerDelegate {
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true)
    }
}
