//
//  MenuViewController.swift
//  PicTranslate
//
//  Created by Duong on 1/7/20.
//  Copyright © 2020 Duong. All rights reserved.
//

import UIKit

enum MenuType: Int {
    case Policy = 0
    case Rate
    case Support
    case Share
    case About
}

protocol MenuViewDelegate: class {
    func didSelectRowAt(index: Int)
}

final class MenuViewController: UIView {
    @IBOutlet private weak var viewOverlay: UIView!
    @IBOutlet private weak var viewContainer: UIView!
    @IBOutlet private weak var tableView: UITableView!
    
    weak var delegate: MenuViewDelegate?
    static let shared = MenuViewController.fromNib() as MenuViewController
    
    private let icons: [UIImage] = [#imageLiteral(resourceName: "ic_privacy"), #imageLiteral(resourceName: "ic_rate"), #imageLiteral(resourceName: "ic_support"), #imageLiteral(resourceName: "ic_more_app"), #imageLiteral(resourceName: "ic_about")]
    private let titles: [String] = ["Privacy Policy", "Rate App", "Support", "Share"]
    
    override func awakeFromNib() {
        super.awakeFromNib()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: MenuTableViewCell.className, bundle: nil), forCellReuseIdentifier: MenuTableViewCell.className)
        self.viewContainer.frame = CGRect(x: 0 - (self.viewContainer.frame.width), y: 0 , width: (self.viewContainer.frame.width) , height: (self.viewContainer.frame.height))
    }
    
    func show() {
        guard let window = UIApplication.shared.keyWindow else {
            return
        }
        window.addSubview(self)
        self.frame = window.frame
        self.alpha = 0
        viewOverlay.alpha = 0.75
        UIView.animateKeyframes(withDuration: 0.25, delay: 0, options: .allowUserInteraction, animations: {
            self.alpha = 1
            self.viewContainer.frame = CGRect(x: (self.viewContainer.frame.width), y: 0 , width: (self.viewContainer.frame.width) , height: (self.viewContainer.frame.height))
            
            
        }, completion: nil)
        tableView.reloadData()
    }
    
    func close() {
        let x = 0 - (self.frame.width)
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveLinear, animations: {
            self.viewOverlay.alpha = 0
            self.viewContainer.frame = CGRect(x: x, y: 0, width: (self.viewContainer.frame.width) , height: (self.viewContainer.frame.height))
        }) { (isCompleted) in
            if isCompleted {
                self.alpha = 1
                self.removeFromSuperview()
            }
        }
    }
    
    @IBAction func tapToOverlayAction(_ sender: Any) {
        close()
    }
    
}
extension MenuViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        close()
        delegate?.didSelectRowAt(index: indexPath.row)
    }
}

extension MenuViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titles.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: MenuTableViewCell.className, for: indexPath) as? MenuTableViewCell else {
            return UITableViewCell()
        }
        cell.setupCell(image: icons[indexPath.row], title: titles[indexPath.row])
        return cell
    }
}
