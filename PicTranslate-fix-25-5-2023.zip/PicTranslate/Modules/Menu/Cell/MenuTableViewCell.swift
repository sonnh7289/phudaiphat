//
//  MenuTableViewCell.swift
//  PicTranslate
//
//  Created by Duong on 1/7/20.
//  Copyright © 2020 Duong. All rights reserved.
//

import UIKit

final class MenuTableViewCell: UITableViewCell {

    @IBOutlet private weak var iconCell: UIImageView!
    @IBOutlet private weak var titleCell: UILabel!
    
    func setupCell(image: UIImage?, title: String) {
        iconCell.image = image
        titleCell.text = title
    }
}
