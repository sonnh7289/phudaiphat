//
//  PolicyViewController.swift
//  CallSanta
//
//  Created by Nhuom Tang on 6/21/19.
//  Copyright © 2019 Luy Nguyen. All rights reserved.
//

import UIKit

class AboutViewController: UIViewController {

    @IBOutlet private weak var textView: UITextView!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        self.title = "About us"
        textView.backgroundColor = UIColor.clear
        textView.textColor = .black
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: false)
    }
}
