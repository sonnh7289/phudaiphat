//
//  CameraViewController.swift
//  PicTranslate
//
//  Created by Duong on 1/8/20.
//  Copyright © 2020 Duong. All rights reserved.
//

import UIKit
import AVFoundation
import Mantis
import DKImagePickerController
import TesseractOCR

final class CameraViewController: BaseViewController {
    // MARK: - Outlet
    @IBOutlet private weak var contentView: UIView!
    @IBOutlet private weak var flashButton: UIButton!
    
    // MARK: - Properties
    var pushToViewController: ((_ text: String) -> Void)?
    
    private var cameraView: CameraSessionView!
    private var isOnFlash: Bool = false {
        didSet {
            flashButton.setImage(UIImage(named: isOnFlash ? "ic_flash" : "ic_noflash"), for: .normal)
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        cameraView.frame = contentView.frame
    }
    
    // MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        isOnFlash = false
        
        cameraView = CameraSessionView(frame: contentView.frame)
        cameraView.contentMode = .center
        //Set the camera view's delegate and add it as a subview
        cameraView.delegate = self

        //Apply animation effect to present the camera view
        let applicationLoadViewIn: CATransition = CATransition()
        applicationLoadViewIn.duration = 0.6
        applicationLoadViewIn.type = CATransitionType.reveal
        applicationLoadViewIn.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeIn)
        cameraView.layer.add(applicationLoadViewIn, forKey: CATransitionType.reveal.rawValue)

        contentView.addSubview(cameraView)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let status = AVCaptureDevice.authorizationStatus(for: .video)
        if status != .authorized && status != .notDetermined {
            showAlertChangeAuthorizationStatus(title: "Alert", message: "No camera access, you will not be able to use this feature. Allow to use camera in settings")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        isOnFlash = false
        cameraView.captureManager.isTorchEnabled = false
    }
    
    // MARK : - Func
    private func recognizeImageWithTesseract(image: UIImage) {
        var content = ""
        showLoading()
        DispatchQueue.main.async {
            if let tesseract = G8Tesseract(language: "eng+fra") {
                tesseract.engineMode = .tesseractCubeCombined
                tesseract.pageSegmentationMode = .auto

                tesseract.image = image
                tesseract.recognize()
                content = (tesseract.recognizedText ?? "").trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: "\n\n", with: "\n")
                self.hideLoading()
                
                if content != "" {
                    DataManager.shared.saveImageDocumentDirectory(image: image, content: content) { (data) in
                        DataManager.shared.saveData(data: data)
                    }
                }
                
                self.dismiss(animated: true) {[weak self] in
                    self?.pushToViewController?(content)
                }
            }
        }
    }
    
    // MARK: - Action
    @IBAction func closeAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func takePhotoAction(_ sender: Any) {
        cameraView.captureManager.captureStillImage()
    }
    
    @IBAction func openLibAction(_ sender: Any) {
        let pickerController = DKImagePickerController()
        pickerController.assetType = .allPhotos
        pickerController.sourceType = .photo
        pickerController.singleSelect = true
        pickerController.autoCloseOnSingleSelect = false
        pickerController.modalPresentationStyle = .fullScreen
        pickerController.didSelectAssets = { [weak self] (assets: [DKAsset]) in
            if assets.count > 0 {
                assets[0].fetchOriginalImage(completeBlock: { [weak self] image, info in
                    if let img = image {
                        let config = Mantis.Config()
                        let cropViewController = Mantis.cropViewController(image: img, config: config)
                        cropViewController.modalPresentationStyle = .fullScreen
                        cropViewController.delegate = self
                        self?.present(cropViewController, animated: true, completion: nil)
                        //self?.recognizeImageWithTesseract(image: img)
                    }
                })
            }
        }
        self.present(pickerController, animated: true, completion: nil)
    }
    
    @IBAction func changeFlashAction(_ sender: Any) {
        let enable = cameraView.captureManager.isTorchEnabled
        isOnFlash = !enable
        cameraView.captureManager.isTorchEnabled = isOnFlash
    }
}

extension CameraViewController: CACameraSessionDelegate {
    func didCapture(_ image: UIImage!) {
        let config = Mantis.Config()
        let cropViewController = Mantis.cropViewController(image: image, config: config)
        cropViewController.modalPresentationStyle = .fullScreen
        cropViewController.delegate = self
        present(cropViewController, animated: true, completion: nil)
    }
}

extension CameraViewController: CropViewControllerDelegate {
    func cropViewControllerDidCrop(_ cropViewController: Mantis.CropViewController, cropped: UIImage, transformation: Mantis.Transformation, cropInfo: Mantis.CropInfo) {
        
    }
    
    func cropViewControllerDidCrop(_ cropViewController: CropViewController, cropped: UIImage, transformation: Transformation) {
        recognizeImageWithTesseract(image: cropped)
        dismiss(animated: false, completion: nil)
    }
    
    func cropViewControllerDidCancel(_ cropViewController: CropViewController, original: UIImage) {
        recognizeImageWithTesseract(image: original)
        dismiss(animated: false, completion: nil)
    }
    
    func cropViewControllerDidCrop(_ cropViewController: CropViewController, cropped: UIImage) {
        recognizeImageWithTesseract(image: cropped)
        dismiss(animated: false, completion: nil)
    }
}

