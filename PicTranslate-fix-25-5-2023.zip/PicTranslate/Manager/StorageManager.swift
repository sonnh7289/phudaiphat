//
//  StorageManager.swift
//  LoginFireBase
//
//  Created by Duong on 10/11/19.
//  Copyright © 2019 Suntech. All rights reserved.
//

import UIKit

class StorageManager: NSObject {
    class func isKeyExits(key: String) -> Bool {
        if (UserDefaults.standard.object(forKey: key) != nil) {
            return true
        }else {
            return false
        }
    }
    
    class func setObject(value: NSObject, forKey key: String){
        UserDefaults.standard.set(value, forKey: key)
        UserDefaults.standard.synchronize()
    }
    
    class func setString(value: String, forKey key: String){
        UserDefaults.standard.setValue(value, forKey: key)
        UserDefaults.standard.synchronize()
    }
    class func getStringForkey(key: String) -> String{
        if let value =  UserDefaults.standard.string(forKey: key) {
            return value
        }
        return  ""
    }
    class func getObjectForkey(key: String) -> NSObject?{
        return UserDefaults.standard.object(forKey: key) as? NSObject
    }
    
    class func setBool(value: Bool, forKey key: String){
        UserDefaults.standard.set(value, forKey: key)
        UserDefaults.standard.synchronize()
    }
    
    class func getBoolForKey(key:String) -> Bool{
        return UserDefaults.standard.bool(forKey: key)
    }
    
    class func removeObjectForKey(key: String){
        UserDefaults.standard.removeObject(forKey: key)
    }
}
