//
//  Extension.swift
//  RingTones
//
//  Created by Duong on 12/21/19.
//  Copyright © 2019 Duong. All rights reserved.
//

import UIKit
import MBProgressHUD
import CRNotifications

extension UIView {
    class func fromNib<T: UIView>() -> T {
        guard let view = Bundle.main.loadNibNamed(String(describing: T.self), owner: nil, options: nil)?.first as? T else {
            return T()
        }
        return view
    }
    
    @IBInspectable
    var cornerRadius: CGFloat {
        get {
            return layer.cornerRadius
        }
        set {
            layer.cornerRadius = newValue
        }
    }
    
    @IBInspectable
    var borderWidth: CGFloat {
        get {
            return layer.borderWidth
        }
        set {
            layer.borderWidth = newValue
        }
    }
    
    @IBInspectable
    var borderColor: UIColor? {
        get {
            if let color = layer.borderColor {
                return UIColor(cgColor: color)
            }
            return nil
        }
        set {
            if let color = newValue {
                layer.borderColor = color.cgColor
            } else {
                layer.borderColor = nil
            }
        }
    }
    
    @IBInspectable
    var shadowRadius: CGFloat {
        get {
            return layer.shadowRadius
        }
        set {
            layer.shadowRadius = newValue
        }
    }
    
    @IBInspectable
    var shadowOpacity: Float {
        get {
            return layer.shadowOpacity
        }
        set {
            layer.shadowOpacity = newValue
        }
    }
    
    @IBInspectable
    var shadowOffset: CGSize {
        get {
            return layer.shadowOffset
        }
        set {
            layer.shadowOffset = newValue
        }
    }
    
    @IBInspectable
    var shadowColor: UIColor? {
        get {
            if let color = layer.shadowColor {
                return UIColor(cgColor: color)
            }
            return nil
        }
        set {
            if let color = newValue {
                layer.shadowColor = color.cgColor
            } else {
                layer.shadowColor = nil
            }
        }
    }
}

extension NSObject {
    var className: String {
        return String(describing: type(of: self))
    }
    
    class var className: String {
        return String(describing: self)
    }
}

extension UIViewController {
    func showLoading() {
        let hub = MBProgressHUD.showAdded(to: self.view, animated: true)
        hub.mode = .indeterminate
        hub.label.text = "Loading"
    }
    
    func hideLoading() {
        MBProgressHUD.hide(for: self.view, animated: true)
    }
    
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }

    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    func showAlertChangeAuthorizationStatus(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let defaultAction = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
            self.openSettingLocation()
        })
        alertController.addAction(defaultAction)

        let cancelBtn = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alertController.addAction(cancelBtn)

        self.present(alertController, animated: true, completion: nil)
    }
    
    func openSettingLocation(){
        guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else {
            return
        }
        
        if UIApplication.shared.canOpenURL(settingsUrl) {
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(settingsUrl, completionHandler: { (success) in
                })
            } else {
                UIApplication.shared.openURL(settingsUrl)
            }
        }
    }
    
    func showActionSheet(title: String, message: String, buttonTitle: String, callback: @escaping () -> ()) {
        let actionSheet = UIAlertController(title: title, message: "", preferredStyle: .actionSheet)
        let messageFont = [kCTFontAttributeName: UIFont.systemFont(ofSize: 16)]
        let messageAttrString = NSMutableAttributedString(string: message, attributes: messageFont as [NSAttributedString.Key : Any])
               
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        let okAction = UIAlertAction(title: buttonTitle, style: .default) { (handler) in
            callback()
        }
        
        if let popoverController = actionSheet.popoverPresentationController {
            popoverController.sourceView = self.view
            popoverController.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
            popoverController.permittedArrowDirections = []
        }
        
        actionSheet.addAction(okAction)
        actionSheet.addAction(cancelAction)
        okAction.setValue(UIColor.red, forKey: "titleTextColor")
        actionSheet.setValue(messageAttrString, forKey: "attributedMessage")
        
        self.present(actionSheet, animated: true, completion: nil)
    }
    
    func showCusomToast(title: String, message: String, dismissDelay: Int, type: CRNotificationType) {
        CRNotifications.showNotification(type: type, title: title, message: message, dismissDelay: TimeInterval(dismissDelay))
    }
}

extension NSObject {
    func background(delay: Double = 0.0, background: (()->Void)? = nil, completion: (() -> Void)? = nil) {
       DispatchQueue.global(qos: .background).async {
           background?()
           if let completion = completion {
               DispatchQueue.main.asyncAfter(deadline: .now() + delay, execute: {
                   completion()
               })
           }
       }
    }
}

extension URL {
    static func checkPath(_ path: String) -> Bool {
        let isFileExist = FileManager.default.fileExists(atPath: path)
        return isFileExist
    }
    
    static func documentsPath(forFileName fileName: String) -> URL? {
        let documents = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        let writePath = URL(string: documents)!.appendingPathComponent(fileName)
        
        var directory: ObjCBool = ObjCBool(false)
        if FileManager.default.fileExists(atPath: documents, isDirectory:&directory) {
            return directory.boolValue ? writePath : nil
        }
        return nil
    }
    
    var attributes: [FileAttributeKey : Any]? {
           do {
               return try FileManager.default.attributesOfItem(atPath: path)
           } catch let error as NSError {
               print("FileAttribute error: \(error)")
           }
           return nil
       }

       var fileSize: UInt64 {
           return attributes?[.size] as? UInt64 ?? UInt64(0)
       }

       var fileSizeString: String {
           return ByteCountFormatter.string(fromByteCount: Int64(fileSize), countStyle: .file)
       }

       var creationDate: Date? {
           return attributes?[.creationDate] as? Date
       }
}

extension Int {
    func asString() -> String {
        let minute = self / 60
        let second = self % 60
        let minuteString = "\(minute)"
        var secondString = "\(second)"
        
        if second < 10 {
            secondString = "0\(second)"
        }
        
        let formattedString = minuteString + ":" + secondString
        return formattedString
    }
}

extension UIColor {
    
    convenience init(red: Int, green: Int, blue: Int) {
        assert(red >= 0 && red <= 255, "Invalid red component")
        assert(green >= 0 && green <= 255, "Invalid green component")
        assert(blue >= 0 && blue <= 255, "Invalid blue component")
        
        self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
    }
    
    convenience init(netHex: Int) {
        self.init(red: (netHex >> 16) & 0xff, green: (netHex >> 8) & 0xff, blue: netHex & 0xff)
    }
    
    static func mainColor() -> UIColor {
        return UIColor(netHex: 0x005059)
    }
    
    convenience init(hex8: UInt32) {
        let divisor = CGFloat(255)
        let alpha   = CGFloat((hex8 & 0xFF000000) >> 24) / divisor
        let red     = CGFloat((hex8 & 0x00FF0000) >> 16) / divisor
        let green   = CGFloat((hex8 & 0x0000FF00) >> 8) / divisor
        let blue    = CGFloat(hex8 & 0x000000FF) / divisor
        self.init(red: red, green: green, blue: blue, alpha: alpha)
    }
}

extension Dictionary {
    func appending(value: Value, key: Key) -> Dictionary {
        var mutable = self
        mutable.updateValue(value, forKey: key)
        return mutable
    }
}

extension UIImage {
    func createThumbImage(width: Float)-> UIImage?{
        let imageData = self.pngData()!
        let options = [
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceThumbnailMaxPixelSize: width] as CFDictionary
        let source = CGImageSourceCreateWithData(imageData as CFData, nil)!
        let imageReference = CGImageSourceCreateThumbnailAtIndex(source, 0, options)!
        let thumbnail = UIImage(cgImage: imageReference)
        return thumbnail
    }
}
extension String {
    
    func nibWithNameiPad()->String{
        var str = self
        if IS_IPAD{
            str = str + "_iPad"
        }
        return str
    }
}
